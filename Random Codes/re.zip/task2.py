#write a program to print all even nos from 1 to 100.
x=0
n=100
while x<n:
    x=x+2
    print(x)