#write a code to print a table 
x=int(input("enter a number "))
y=1
while y<=10:
    result=x*y
    y=y+1
    print(x,"x",y,"=",result)