#Write a program to print all natural numbers from 1 to n.
#starting point 
x=1
#ending point
n=int(input("enter a number "))
#while loop condition 
while x<n:
#run loop until x is less than 1 
     print(x) 
#increase value by 1 in eveey step of loop
     x=x+1
